package com.example.gslc1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_FNAME = "com.example.gslc1.EXTRA_FNAME";
    public static final String EXTRA_LNAME = "com.example.gslc1.EXTRA_LNAME";
    public static final String EXTRA_EMAIL = "com.example.gslc1.EXTRA_EMAIL";
    public static final String EXTRA_PHONE = "com.example.gslc1.EXTRA_PHONE";
    public static final String EXTRA_AGE = "com.example.gslc1.EXTRA_AGE";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button newPage = findViewById(R.id.register);
        newPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText txtfname = findViewById(R.id.txtfname);
                String fname = txtfname.getText().toString();

                EditText txtlname = findViewById(R.id.txtlname);
                String lname = txtlname.getText().toString();

                EditText txtemail = findViewById(R.id.txtemail);
                String email = txtemail.getText().toString();

                EditText txtphone = findViewById(R.id.txtphone);
                String phone = txtphone.getText().toString();

                EditText txtage = findViewById(R.id.txtage);
                int age = Integer.parseInt(txtage.getText().toString());

                Intent intent = new Intent(MainActivity.this, page2.class);
                intent.putExtra(EXTRA_FNAME, fname);
                intent.putExtra(EXTRA_LNAME, lname);
                intent.putExtra(EXTRA_EMAIL, email);
                intent.putExtra(EXTRA_PHONE, phone);
                intent.putExtra(EXTRA_AGE, age);
                startActivity(intent);
            }
        });
    }
}