package com.example.gslc1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class page2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
        Intent intent = getIntent();
        String fname = intent.getStringExtra(MainActivity.EXTRA_FNAME);
        String lname = intent.getStringExtra(MainActivity.EXTRA_LNAME);
        String email = intent.getStringExtra(MainActivity.EXTRA_EMAIL);
        String phone = intent.getStringExtra(MainActivity.EXTRA_PHONE);
        int age = intent.getIntExtra(MainActivity.EXTRA_AGE, 0);

        TextView textName = findViewById(R.id.textName);
        TextView textAge = findViewById(R.id.textAge);
        TextView textPhone = findViewById(R.id.textPhone);
        TextView textEmail = findViewById(R.id.textEmail);

        textName.setText("Name: " + fname + " " + lname);
        textAge.setText("Age: " + age);
        textPhone.setText("Phone: " + phone);
        textEmail.setText("Email :" + email);

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(page2.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}